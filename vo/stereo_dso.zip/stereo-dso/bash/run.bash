	bin/dso_dataset \
		files=XXXXX/sequence_XX \
		calib=XXXXX/sequence_XX/para/camera.txt \
		preset=0 \
		mode=1