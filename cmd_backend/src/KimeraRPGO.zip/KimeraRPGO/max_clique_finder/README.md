See the original Fast Max-Clique Finder library at: http://cucis.ece.northwestern.edu/projects/MAXCLIQUE/
